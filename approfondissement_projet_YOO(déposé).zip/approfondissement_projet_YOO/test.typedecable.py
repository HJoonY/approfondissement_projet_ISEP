from fonction_typedecable import *

print("<<cas 1>>")
x = 1
print("sortie:")
print(typedecable(x))

print("<<cas 2>>")
x=2
print("sortie:")
print(typedecable(x))
